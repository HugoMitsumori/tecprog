Hugo Mitsumori  8941262
Paulo Araujo    8941112

Instruções de uso

Geração do código C:
        ./montador < codigo_assembly > motor.c
        Ex: ./montador < fibo > motor.c

Compilação:
        make

Execução:
        ./motor


* Incluimos 3 arquivos assembly de exemplo: soma, fibo e recursion