#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "posicao.h"

/* posição na matriz correspondente ao vizinho d posição local na direção dada */
Posicao vizinho(Posicao local, int direcao) {
  Posicao pos;
  switch (direcao) {
    case NORDESTE:
      pos.i = local.i - 1;
      if (local.i % 2 == 0)        
        pos.j = local.j;
      else
        pos.j = local.j + 1;
      break;
    case LESTE:
      pos.i = local.i;
      pos.j = local.j + 1;
      break;
    case SUDESTE:          
      pos.i = local.i + 1;
      if (local.i % 2 == 0)
        pos.j = local.j;
      else
        pos.j = local.j + 1;
      break;
    case SUDOESTE:
      pos.i = local.i + 1;
      if (local.i % 2 == 0)
        pos.j = local.j - 1;
      else
        pos.j = local.j;
      break;
    case OESTE:
      pos.i = local.i;
      pos.j = local.j - 1;
      break;
    case NOROESTE:
      pos.i = local.i - 1;
      if (local.i % 2 == 0)
        pos.j = local.j - 1;
      else
        pos.j = local.j;
      break;
  }
  return pos;
}

/* distancia entre duas posições de matriz*/
int distancia (Posicao pos1, Posicao pos2) {
  int dist_i, dist_j;
  dist_i = abs(pos1.i - pos2.i);
  dist_j = abs(pos1.j - pos2.j);
  if (dist_i > dist_j)
    return dist_i;
  return dist_j;
}

/* distancia entre uma posição e um par (i,j) na matriz*/
int distancia_ij (Posicao pos, int i, int j) {
  int dist_i, dist_j;
  dist_i = abs(pos.i - i);
  dist_j = abs(pos.j - j);
  if (dist_i > dist_j)
    return dist_i;
  return dist_j;
}

